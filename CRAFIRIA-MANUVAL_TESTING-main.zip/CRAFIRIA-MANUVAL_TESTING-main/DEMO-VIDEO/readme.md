demo-video file for the software testing
