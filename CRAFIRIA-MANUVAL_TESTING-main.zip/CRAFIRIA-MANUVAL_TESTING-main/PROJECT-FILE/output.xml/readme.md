<?xml version="1.0" encoding="UTF-8"?>
<robot generator="Robot 6.0.2 (Python 3.8.6 on win32)" generated="20230709 17:35:13.517" rpa="false" schemaversion="3">
<suite id="s1" name="Test Web Login User" source="D:\Python Automation\Craferia_Automation\testCases\Test_Web_Login_User.robot">
<test id="s1-t1" name="CRAFERIA-111: Login to Craferia applicaiton" line="19">
<kw name="Setup Browser" type="SETUP">
<msg timestamp="20230709 17:35:13.543" level="FAIL">No keyword with name 'Setup Browser' found.</msg>
<status status="FAIL" starttime="20230709 17:35:13.543" endtime="20230709 17:35:13.543"/>
</kw>
<kw name="Close Browser" type="TEARDOWN">
<msg timestamp="20230709 17:35:13.544" level="FAIL">No keyword with name 'Close Browser' found.</msg>
<status status="FAIL" starttime="20230709 17:35:13.544" endtime="20230709 17:35:13.544">No keyword with name 'Close Browser' found.</status>
</kw>
<tag>Login</tag>
<tag>Smoke</tag>
<status status="FAIL" starttime="20230709 17:35:13.541" endtime="20230709 17:35:13.544">Setup failed:
No keyword with name 'Setup Browser' found.

Also teardown failed:
No keyword with name 'Close Browser' found.</status>
</test>
<status status="FAIL" starttime="20230709 17:35:13.520" endtime="20230709 17:35:13.545"/>
</suite>
<statistics>
<total>
<stat pass="0" fail="1" skip="0">All Tests</stat>
</total>
<tag>
<stat pass="0" fail="1" skip="0">Login</stat>
<stat pass="0" fail="1" skip="0">Smoke</stat>
</tag>
<suite>
<stat pass="0" fail="1" skip="0" id="s1" name="Test Web Login User">Test Web Login User</stat>
</suite>
</statistics>
<errors>
<msg timestamp="20230709 17:35:13.540" level="ERROR">Error in file 'D:\Python Automation\Craferia_Automation\testCases\Test_Web_Login_User.robot' on line 2: Resource file '..\pageObjects\Page_object_athena_web.robot' does not exist.</msg>
</errors>
</robot>
